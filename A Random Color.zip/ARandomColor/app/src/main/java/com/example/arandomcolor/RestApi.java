package com.example.arandomcolor;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RestApi {
    @GET("id")
    Call<Model> getdata(@Query("rgb") String rgbstring);
}