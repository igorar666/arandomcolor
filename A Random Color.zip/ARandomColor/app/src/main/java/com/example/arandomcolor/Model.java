package com.example.arandomcolor;

import java.util.HashMap;

public class Model {
    public HashMap hex;
    public HashMap rgb;
    public HashMap hsl;
    public HashMap hsv;
    public HashMap name;
    public HashMap cmyk;
    public HashMap XYZ;
    public HashMap image;
    public HashMap contrast;
    public HashMap _links;
    public HashMap _embedded;
}