package com.example.arandomcolor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private ConstraintLayout layout;
    private Button button;
    private TextView textView;
    private TextView hextext;
    private Window window;
    private EditText Rtext;
    private EditText Gtext;
    private EditText Btext;




    protected void ChangeColor(int r, int g, int b) {
        textView = (TextView) findViewById(R.id.NameText);
        hextext = (TextView) findViewById(R.id.HEXtext);
        layout = findViewById(R.id.layout);
        textView.setText("Loading...");
        hextext.setText("Loading...");

        int color = Color.rgb(r, g, b);

        layout.setBackgroundColor(color);
        window.setStatusBarColor(color);

        String rgb = Integer.toString(r) + " " + Integer.toString(g) + " " + Integer.toString(b);

        String rgbstring = Integer.toString(r) + "," + Integer.toString(g) + "," + Integer.toString(b);
        setColorName(rgbstring);
    }

    protected void GetRandomColor(){
        Random random = new Random();
        int r = random.nextInt(256);
        int g = random.nextInt(256);
        int b = random.nextInt(256);
        Rtext.setText(Integer.toString(r));
        Gtext.setText(Integer.toString(g));
        Btext.setText(Integer.toString(b));
    }

    void setColorName(String rgbstring) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://www.thecolorapi.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RestApi service = retrofit.create(RestApi.class);
        Call<Model> call = service.getdata(rgbstring);
        call.enqueue(new Callback<Model>() {
            @Override
            public void onResponse(Call<Model> call, Response<Model> response) {
                try {
                    HashMap namehash = response.body().name;
                    HashMap contrast = response.body().contrast;
                    HashMap hexhash = response.body().hex;
                    String colorname = namehash.get("value").toString();
                    String contrasthex = contrast.get("value").toString();
                    String hex = hexhash.get("value").toString();

                    textView.setText(colorname);
                    textView.setTextColor(Color.parseColor(contrasthex));

                    hextext.setText(hex);
                    hextext.setTextColor(Color.parseColor(contrasthex));

                    Rtext.setTextColor(Color.parseColor(contrasthex));
                    Gtext.setTextColor(Color.parseColor(contrasthex));
                    Btext.setTextColor(Color.parseColor(contrasthex));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<Model> call, Throwable t) {
            }
        });
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        Rtext = findViewById(R.id.editTextR);
        Gtext = findViewById(R.id.editTextG);
        Btext = findViewById(R.id.editTextB);
        TextWatcher EditedTextFunc = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                try{
                    if(Integer.parseInt(Rtext.getText().toString()) > 255){
                        Rtext.setText("255");
                    }
                    if(Integer.parseInt(Gtext.getText().toString()) > 255){
                        Gtext.setText("255");
                    }
                    if(Integer.parseInt(Btext.getText().toString()) > 255){
                        Btext.setText("255");
                    }
                    ChangeColor(Integer.parseInt(Rtext.getText().toString()), Integer.parseInt(Gtext.getText().toString()), Integer.parseInt(Btext.getText().toString()));

                } catch (Exception e){}
            }
        };
        Rtext.addTextChangedListener(EditedTextFunc);
        Gtext.addTextChangedListener(EditedTextFunc);
        Btext.addTextChangedListener(EditedTextFunc);


        window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        GetRandomColor();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetRandomColor();
            }
        });
    }
}